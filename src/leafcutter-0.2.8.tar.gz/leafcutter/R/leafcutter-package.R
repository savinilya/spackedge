#' The 'leafcutter' package.
#' 
#' @description A DESCRIPTION OF THE PACKAGE
#' 
#' @docType package
#' @name leafcutter-package
#' @aliases leafcutter
#' @useDynLib leafcutter, .registration = TRUE
#' @import methods
#' @import Rcpp
#' @import rstantools
#' @importFrom rstan optimizing
#' 
#' @references 
#' Stan Development Team (2018). RStan: the R interface to Stan. R package version 2.17.4. http://mc-stan.org
#' 
NULL
