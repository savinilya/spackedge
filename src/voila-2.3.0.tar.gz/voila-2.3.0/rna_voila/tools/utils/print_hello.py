def foo(bar="hello"):
    return bar
