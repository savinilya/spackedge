import unittest


class TestJunctionDictionaryMethods(unittest.TestCase):
    def test_junction_dictionary(self):
        # print(sys.argv)
        # args = JunctionDictionaryTool().arguments()
        # junction_dictionary(args.parse_args())
        pass
